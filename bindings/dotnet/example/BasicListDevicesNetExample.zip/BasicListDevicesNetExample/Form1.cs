﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Windows.Forms;
using TelldusWrapper;

namespace BasicListDevicesExample
{
	/// <summary>
	/// .NET example, listing devices and their status with manual update
	/// Telldus Center must be installed for this example to work. 
	/// One or more devices should have been added to make this example useful.
	/// Make sure that TelldusNETWrapper.dll is added to your GAC (should have been done automatically if development files were selected
	/// during the Telldus Center installation). Otherwise is can added manually by running "gacutil /i TelldusNetWrapper.dll" in the
	/// Telldus Center installation directory.
	/// Another alternative is to add a reference directly to the file "TelldusNETWrapper.dll" in this project (available in the Telldus Center installation directory).
	/// TelldusCore.dll is needed too, and must exist in the system directory (SysWOW64 or System32), where it should have been added by the Telldus Center installer.
	/// </summary>
	public partial class Form1 : Form
	{
		public Form1()
		{
			InitializeComponent();
		}

		~Form1()
		{
			Application.Exit();
		}

		private void Form1_Load(object sender, EventArgs e)
		{
			try
			{
				loadDevices();
			}
			catch (Exception exc)
			{
				//error handling if DLL is missing or wrong format (e.g. compiled for different platform)
				if (exc is System.DllNotFoundException || exc is System.BadImageFormatException)
				{
					btnUpdate.Visible = false;
					lblMessage.Text = "DLL not found/incorrect version (TelldusCore.dll and TelldusNETWrapper.dll are needed)";
				}
				else
				{
					throw exc;
				}
			}
		}

		private void loadDevices()
		{
			flowLayoutPanel1.Controls.Clear();
			Font buttonFont = new Font("arial", 3);
			int numberOfDevices = TelldusNETWrapper.tdGetNumberOfDevices();		//get number of devices, negative value indicate error
			if (numberOfDevices < 0)
			{
				//error, get the error as a human readable string
				lblMessage.Text = TelldusNETWrapper.tdGetErrorString(numberOfDevices);
				return;
			}

			flowLayoutPanel1.FlowDirection = FlowDirection.TopDown;
			for (int i = 0; i < numberOfDevices; i++)
			{
				//fill panel with devices, each device lists name, status (on/off), and dim value where applicable
				
				int deviceId = TelldusNETWrapper.tdGetDeviceId(i);	//get id for device at this position, use id from here on
				string deviceName = TelldusNETWrapper.tdGetName(deviceId);

				//last sent command shows current status of device, as far as we can tell (last sent value from any client (e.g. TelldusCenter) or
				//   last value received from Telldus Duo, if such exists, for this device)
				int status = TelldusNETWrapper.tdLastSentCommand(deviceId, TelldusNETWrapper.TELLSTICK_DIM | TelldusNETWrapper.TELLSTICK_TURNON | TelldusNETWrapper.TELLSTICK_TURNOFF);
				string value = TelldusNETWrapper.tdLastSentValue(deviceId);		//value too, if it exists (e.g. dimmer)

				FlowLayoutPanel flp = new FlowLayoutPanel();
				flp.FlowDirection = FlowDirection.LeftToRight;
				flp.Width = 375;
				flp.Height = 15;
				Label lblName = new Label();
				lblName.Name = "lblName";
				lblName.Text = deviceName;
				PictureBox pbStatus = new PictureBox();
				Label lblStatus = new Label();
				SetStatus(pbStatus, lblStatus, status, value);
				Size tempSize = pbStatus.Size;
				tempSize.Height = 12;
				tempSize.Width = 12;
				pbStatus.Size = tempSize;
				pbStatus.SizeMode = PictureBoxSizeMode.StretchImage;
				flp.Controls.Add(lblName);
				flp.Controls.Add(pbStatus);
				flp.Controls.Add(lblStatus);
				flp.Tag = deviceId;
				flowLayoutPanel1.Controls.Add(flp);
			}
			TelldusNETWrapper.tdClose();	//release resources in the Telldus libraries
		}

		/// <summary>
		/// Set status image/dimmer value
		/// </summary>
		/// <param name="pbStatus"></param>
		/// <param name="lblStatus"></param>
		/// <param name="status"></param>
		/// <param name="value"></param>
		private void SetStatus(PictureBox pbStatus, Label lblStatus, int status, string value)
		{
			if (status == 1)
			{
				pbStatus.ImageLocation = "images/devices.png";
			}
			else if (status == 2)
			{
				pbStatus.ImageLocation = "images/devices-bw.png";
			}
			else
			{
				lblStatus.Text = String.Concat("Dim: ", value);
				pbStatus.Visible = false;
			}
		}

		/// <summary>
		/// Refresh values to reflect possible changes in device status or name
		/// Done manually since this example doesn't use callbacks
		/// </summary>
		/// <param name="sender"></param>
		/// <param name="e"></param>
		private void btnUpdate_Click(object sender, EventArgs e)
		{
			loadDevices();
		}
	}
}
