﻿namespace BasicTurnOnDeviceExample
{
	partial class Form1
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.lblMessage = new System.Windows.Forms.Label();
			this.pbStatus = new System.Windows.Forms.PictureBox();
			this.lblName = new System.Windows.Forms.Label();
			this.lblModel = new System.Windows.Forms.Label();
			this.btnOn = new System.Windows.Forms.Button();
			this.btnOff = new System.Windows.Forms.Button();
			this.lblStatus = new System.Windows.Forms.Label();
			((System.ComponentModel.ISupportInitialize)(this.pbStatus)).BeginInit();
			this.SuspendLayout();
			// 
			// lblMessage
			// 
			this.lblMessage.AutoSize = true;
			this.lblMessage.Location = new System.Drawing.Point(59, 28);
			this.lblMessage.Name = "lblMessage";
			this.lblMessage.Size = new System.Drawing.Size(0, 13);
			this.lblMessage.TabIndex = 3;
			// 
			// pbStatus
			// 
			this.pbStatus.Location = new System.Drawing.Point(62, 81);
			this.pbStatus.Name = "pbStatus";
			this.pbStatus.Size = new System.Drawing.Size(49, 48);
			this.pbStatus.TabIndex = 4;
			this.pbStatus.TabStop = false;
			// 
			// lblName
			// 
			this.lblName.AutoSize = true;
			this.lblName.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblName.Location = new System.Drawing.Point(139, 71);
			this.lblName.Name = "lblName";
			this.lblName.Size = new System.Drawing.Size(0, 16);
			this.lblName.TabIndex = 5;
			// 
			// lblModel
			// 
			this.lblModel.AutoSize = true;
			this.lblModel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblModel.Location = new System.Drawing.Point(139, 111);
			this.lblModel.Name = "lblModel";
			this.lblModel.Size = new System.Drawing.Size(0, 16);
			this.lblModel.TabIndex = 6;
			// 
			// btnOn
			// 
			this.btnOn.Image = global::BasicTurnOnDeviceExample.Properties.Resources.devices;
			this.btnOn.Location = new System.Drawing.Point(418, 63);
			this.btnOn.Name = "btnOn";
			this.btnOn.Size = new System.Drawing.Size(75, 70);
			this.btnOn.TabIndex = 7;
			this.btnOn.Text = "ON";
			this.btnOn.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
			this.btnOn.UseVisualStyleBackColor = true;
			this.btnOn.Click += new System.EventHandler(this.btnOn_Click);
			// 
			// btnOff
			// 
			this.btnOff.Image = global::BasicTurnOnDeviceExample.Properties.Resources.devices_bw;
			this.btnOff.Location = new System.Drawing.Point(517, 63);
			this.btnOff.Name = "btnOff";
			this.btnOff.Size = new System.Drawing.Size(75, 70);
			this.btnOff.TabIndex = 8;
			this.btnOff.Text = "OFF";
			this.btnOff.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
			this.btnOff.UseVisualStyleBackColor = true;
			this.btnOff.Click += new System.EventHandler(this.btnOff_Click);
			// 
			// lblStatus
			// 
			this.lblStatus.AutoSize = true;
			this.lblStatus.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.lblStatus.Location = new System.Drawing.Point(59, 94);
			this.lblStatus.Name = "lblStatus";
			this.lblStatus.Size = new System.Drawing.Size(0, 16);
			this.lblStatus.TabIndex = 9;
			// 
			// Form1
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(630, 191);
			this.Controls.Add(this.lblStatus);
			this.Controls.Add(this.btnOff);
			this.Controls.Add(this.btnOn);
			this.Controls.Add(this.lblModel);
			this.Controls.Add(this.lblName);
			this.Controls.Add(this.pbStatus);
			this.Controls.Add(this.lblMessage);
			this.Name = "Form1";
			this.Text = "Basic Turn On Device Example";
			this.Load += new System.EventHandler(this.Form1_Load);
			((System.ComponentModel.ISupportInitialize)(this.pbStatus)).EndInit();
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.Label lblMessage;
		private System.Windows.Forms.PictureBox pbStatus;
		private System.Windows.Forms.Label lblName;
		private System.Windows.Forms.Label lblModel;
		private System.Windows.Forms.Button btnOn;
		private System.Windows.Forms.Button btnOff;
		private System.Windows.Forms.Label lblStatus;
	}
}

