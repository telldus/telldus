﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Windows.Forms;
using TelldusWrapper;

namespace BasicTurnOnDeviceExample
{
	/// <summary>
	/// .NET example, turn on/off a device, and see status
	/// </summary>
	public partial class Form1 : Form
	{
		int SUPPORTED_METHODS = TelldusNETWrapper.TELLSTICK_TURNON | TelldusNETWrapper.TELLSTICK_TURNOFF | TelldusNETWrapper.TELLSTICK_DIM;
		int deviceId;

		public Form1()
		{
			InitializeComponent();
		}

		~Form1()
		{
			Application.Exit();
		}

		private void Form1_Load(object sender, EventArgs e)
		{
			try
			{
				loadDevice();
			}
			catch (Exception exc)
			{
				//error handling if DLL is missing or wrong format (e.g. compiled for different platform)
				if (exc is System.DllNotFoundException || exc is System.BadImageFormatException)
				{
					btnOn.Visible = false;
					btnOff.Visible = false;
					lblMessage.Text = "DLL not found (TelldusCore.dll and TelldusNETWrapper.dll are needed)";
				}
				else
				{
					throw exc;
				}
			}
		}

		private void loadDevice()
		{
			int numberOfDevices = TelldusNETWrapper.tdGetNumberOfDevices();	//get number of devices, to make sure that devices exists
			if (numberOfDevices > 0)
			{
				deviceId = TelldusNETWrapper.tdGetDeviceId(0);	//just pick the first one, get the id of that device, and use it
				UpdateStatus(deviceId);
			}
			else if (numberOfDevices < 0)
			{
				//negative values indicate errors
				btnOn.Visible = false;
				btnOff.Visible = false;
				lblMessage.Text = TelldusNETWrapper.tdGetErrorString(numberOfDevices);	//get a human readable error message for this error code
			}
			else
			{
				//no devices configured, do that first
				btnOn.Visible = false;
				btnOff.Visible = false;
				lblMessage.Text = "No devices configured";
			}

			TelldusNETWrapper.tdClose();	//release resources in the Telldus libraries
		}

		void btnOn_Click(object sender, EventArgs e)
		{
			TelldusNETWrapper.tdTurnOn(deviceId);	//turn on the device
			TelldusNETWrapper.tdClose();	//release resources in the Telldus libraries
			UpdateStatus(deviceId);
		}

		void btnOff_Click(object sender, EventArgs e)
		{
			TelldusNETWrapper.tdTurnOff(deviceId);	//turn off the device
			TelldusNETWrapper.tdClose();	//release resources in the Telldus libraries
			UpdateStatus(deviceId);
		}

		/// <summary>
		/// Set status image/dimmer value
		/// </summary>
		/// <param name="pbStatus"></param>
		/// <param name="lblStatus"></param>
		/// <param name="status"></param>
		/// <param name="value"></param>
		private void SetStatus(int status, string value)
		{
			if (status == 1)
			{
				pbStatus.Image = Properties.Resources.devices;
				pbStatus.Visible = true;
				lblStatus.Visible = false;
			}
			else if (status == 2)
			{
				pbStatus.Image = Properties.Resources.devices_bw;
				pbStatus.Visible = true;
				lblStatus.Visible = false;
			}
			else
			{
				lblStatus.Visible = true;
				lblStatus.Text = String.Concat("Dim: ", value);
				pbStatus.Visible = false;
			}
		}

		/// <summary>
		/// Set values that might have changed
		/// </summary>
		/// <param name="deviceId"></param>
		private void UpdateStatus(int deviceId)
		{
			lblName.Text = TelldusNETWrapper.tdGetName(deviceId);
			lblModel.Text = TelldusNETWrapper.tdGetModel(deviceId);
			int status = TelldusNETWrapper.tdLastSentCommand(deviceId, SUPPORTED_METHODS);
			string value = TelldusNETWrapper.tdLastSentValue(deviceId);
			TelldusNETWrapper.tdClose();
			SetStatus(status, value);
		}
	}
}
